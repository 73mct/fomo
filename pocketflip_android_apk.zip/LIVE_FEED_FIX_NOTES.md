# PocketFlip live-feed repair

## What changed
- Solana account WebSocket is now the primary live feed.
- Pump.fun bonding-curve accounts are subscribed directly.
- AMM token and WSOL vaults are both subscribed on the same socket.
- Solana's server-assigned subscription IDs are mapped to the correct vault.
- HTTP RPC is throttled to a recovery fallback instead of running every 200 ms.
- The service checks the stream once per second and reopens the WebSocket after a close/failure.
- Removed the PumpPortal trade-stream dependency from the live-price path.
- Tightened Pump.fun pool detection to verify the owning program instead of guessing from account size.
- Fixed the GitHub Actions workflow so it actually runs `gradle assembleDebug`.

## Important limitations
- The app still uses public Solana RPC endpoints. They are free to try but have no guaranteed latency, uptime, or rate limits.
- Initial metadata and pool discovery still use DexScreener plus Solana RPC.
- This source has not been built or tested against a live token in this environment. Build it in GitHub Actions, install it, then compare the HUD against FOMO.
- Some AMM designs and non-WSOL quote pools may need additional pool-specific decoding. Do not assume every Solana DEX is supported equally.
