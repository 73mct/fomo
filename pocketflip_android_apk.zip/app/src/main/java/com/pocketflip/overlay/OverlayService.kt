package com.pocketflip.overlay

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        @Volatile
        var isRunning: Boolean = false

        @Volatile
        private var instance: OverlayService? = null

        fun onInstantScreenMcDetected(screenMc: Double) {
            val svc = instance ?: return
            svc.applyInstantScreenMc(screenMc)
        }
    }

    private lateinit var windowManager: WindowManager
    private lateinit var rootContainer: FrameLayout
    private lateinit var params: WindowManager.LayoutParams
    private val mainHandler = Handler(Looper.getMainLooper())
    private var poller: ScheduledExecutorService? = null

    // State 2: Minimized Live PnL Pill Views (Floats over fomo chart without blocking touches)
    private lateinit var pillCard: LinearLayout
    private lateinit var pillTickerText: TextView
    private lateinit var pillPnlText: TextView
    private lateinit var pillMultBadge: TextView
    private lateinit var pillSubText: TextView

    // State 1: Expanded PocketFlip Floating HUD Views (Matches user's HUD screenshot)
    private lateinit var hudCard: LinearLayout
    private lateinit var hudTokenIcon: ImageView
    private lateinit var hudTickerBadge: TextView
    private lateinit var hudLiveMcValue: TextView
    private lateinit var hudLivePnlValue: TextView
    private lateinit var hudMultipleValue: TextView
    private lateinit var hudBoughtMcValue: TextView
    private lateinit var hudSellMcValue: TextView
    private lateinit var hudBagLeftValue: TextView
    private lateinit var hudSolBalanceText: TextView
    private lateinit var hudFeeInfoText: TextView
    private lateinit var buyButtonsRow: LinearLayout
    private lateinit var sellButtonsRow: LinearLayout
    private lateinit var customSellPctInput: EditText

    private var currentToken: TokenInfo = TokenInfo(
        ca = "7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr",
        name = "Popcat",
        symbol = "POPCAT",
        priceUsd = 0.0452,
        solUsdPrice = 185.0,
        marketCap = 41890000.0,
        liquidityUsd = 2830000.0,
        volume24h = 10050000.0,
        imageUrl = ""
    )

    private val repoListener: () -> Unit = {
        mainHandler.post { refreshHudAndPillUI() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        TradeRepository.init(this)
        isRunning = true
        instance = this
        startForegroundServiceNotification()

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // Start in Expanded HUD or Minimized Pill
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(140)
        }

        buildNativeOverlayViews()
        TradeRepository.addListener(repoListener)
        try {
            windowManager.addView(rootContainer, params)
        } catch (e: Exception) {
            Toast.makeText(this, "Permission required: Enable 'Display over other apps'", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }

        // Dual-Engine Parallel Poller (220ms Jupiter Live Price + 600ms Cache-Busted DEX Screener)
        poller = Executors.newScheduledThreadPool(2)
        poller?.scheduleWithFixedDelay({
            val activeCa = TradeRepository.settings.activeCa
            val fetched = DexScreenerClient.fetchTokenSync(activeCa)
            if (fetched != null) {
                // If Screen-Sync updated within the last 1.8s, keep the 0ms Screen-Sync Market Cap!
                val screenAge = System.currentTimeMillis() - FomoScreenReaderService.lastScreenUpdateMs
                val finalToken = if (FomoScreenReaderService.isConnected && screenAge < 1800L && FomoScreenReaderService.lastScreenMc > 0.0) {
                    val ratio = FomoScreenReaderService.lastScreenMc / fetched.marketCap.coerceAtLeast(1.0)
                    fetched.copy(
                        marketCap = FomoScreenReaderService.lastScreenMc,
                        priceUsd = fetched.priceUsd * ratio
                    )
                } else {
                    fetched
                }
                currentToken = finalToken
                TradeRepository.syncLiveTokenData(finalToken)
                mainHandler.post { refreshHudAndPillUI() }

                if (fetched.imageUrl.isNotEmpty() && hudTokenIcon.tag != fetched.imageUrl) {
                    hudTokenIcon.tag = fetched.imageUrl
                    DexScreenerClient.loadTokenBitmap(fetched.imageUrl) { bmp ->
                        if (bmp != null) {
                            mainHandler.post { hudTokenIcon.setImageBitmap(bmp) }
                        }
                    }
                }
            }
        }, 0, 600, TimeUnit.MILLISECONDS)

        poller?.scheduleWithFixedDelay({
            val screenAge = System.currentTimeMillis() - FomoScreenReaderService.lastScreenUpdateMs
            if (FomoScreenReaderService.isConnected && screenAge < 1800L) return@scheduleWithFixedDelay
            val activeCa = TradeRepository.settings.activeCa
            val fastTick = DexScreenerClient.fetchFastJupiterTick(activeCa)
            if (fastTick != null) {
                currentToken = fastTick
                TradeRepository.syncLiveTokenData(fastTick)
                mainHandler.post { refreshHudAndPillUI() }
            }
        }, 150, 220, TimeUnit.MILLISECONDS)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildNativeOverlayViews() {
        rootContainer = FrameLayout(this)

        // =====================================================================
        // STATE 2: MINIMIZED LIVE PNL PILL (Monitor fomo chart unobstructed)
        // =====================================================================
        pillCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(7), dp(12), dp(7))
            background = roundedBox("#F20B0F19", "#10B981", dp(20), dp(2))
            visibility = View.GONE
        }

        val pfBadge = TextView(this).apply {
            text = "PF"
            setTextColor(Color.parseColor("#090B10"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = roundedBox("#10B981", "#34D399", dp(14), dp(1))
            layoutParams = LinearLayout.LayoutParams(dp(28), dp(28)).apply {
                rightMargin = dp(8)
            }
        }

        val pillTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val pillTopRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        pillTickerText = TextView(this).apply {
            text = "\$POPCAT"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 0, dp(6), 0)
        }

        pillPnlText = TextView(this).apply {
            text = "+0.000 SOL"
            setTextColor(Color.parseColor("#10B981"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 0, dp(6), 0)
        }

        pillMultBadge = TextView(this).apply {
            text = "1.00x"
            setTextColor(Color.parseColor("#22D3EE"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(5), dp(1), dp(5), dp(1))
            background = roundedBox("#164E63", "#22D3EE", dp(6), dp(1))
        }

        pillTopRow.addView(pillTickerText)
        pillTopRow.addView(pillPnlText)
        pillTopRow.addView(pillMultBadge)

        pillSubText = TextView(this).apply {
            text = "Bought: — → Now: $41.9M • Tap to Trade"
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.MONOSPACE
        }

        pillTextCol.addView(pillTopRow)
        pillTextCol.addView(pillSubText)

        pillCard.addView(pfBadge)
        pillCard.addView(pillTextCol)

        // =====================================================================
        // STATE 1: EXPANDED POCKETFLIP FLOATING HUD (Matches Screenshot)
        // =====================================================================
        hudCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#F50D111A", "#263248", dp(18), dp(1))
            layoutParams = FrameLayout.LayoutParams(dp(340), FrameLayout.LayoutParams.WRAP_CONTENT)
        }

        // 1. HUD Top Header Drag Bar
        val hudHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(9), dp(10), dp(9))
            background = roundedTopBox("#131B2E", dp(18))
        }

        val greenDot = View(this).apply {
            background = roundedBox("#10B981", "#10B981", dp(6), 0)
            layoutParams = LinearLayout.LayoutParams(dp(9), dp(9)).apply {
                rightMargin = dp(6)
            }
        }

        hudTokenIcon = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)).apply {
                rightMargin = dp(5)
            }
            setImageResource(android.R.drawable.sym_def_app_icon)
        }

        val hudTitle = TextView(this).apply {
            text = "PocketFlip HUD"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        hudTickerBadge = TextView(this).apply {
            text = "\$POPCAT"
            setTextColor(Color.parseColor("#34D399"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(7), dp(3), dp(7), dp(3))
            background = roundedBox("#064E3B", "#10B981", dp(6), dp(1))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = dp(5) }
        }

        val pasteCaBtn = TextView(this).apply {
            text = "Paste CA"
            setTextColor(Color.parseColor("#38BDF8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = roundedBox("#1E293B", "#334155", dp(6), dp(1))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = dp(5) }
            setOnClickListener { pasteCaFromClipboard() }
        }

        val minimizeBtn = TextView(this).apply {
            text = "—"
            setTextColor(Color.parseColor("#E2E8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
            background = roundedBox("#1E293B", "#475569", dp(8), dp(1))
            layoutParams = LinearLayout.LayoutParams(dp(28), dp(26))
            setOnClickListener { switchToMinimizedPill() }
        }

        hudHeader.addView(greenDot)
        hudHeader.addView(hudTokenIcon)
        hudHeader.addView(hudTitle)
        hudHeader.addView(hudTickerBadge)
        hudHeader.addView(pasteCaBtn)
        hudHeader.addView(minimizeBtn)

        // 2. HUD Body Container
        val hudBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
        }

        // Metrics Box (Live Market Cap | Live PnL | Multiple + Bought MC | Sell MC | Bag Left %)
        val metricsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = roundedBox("#090C14", "#1E293B", dp(12), dp(1))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(10) }
        }

        val metricsTopRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 3f
        }

        // Col 1: Live Market Cap
        val colMc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        colMc.addView(makeLabel("Live Market Cap"))
        hudLiveMcValue = TextView(this).apply {
            text = "$41.89M"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
        }
        colMc.addView(hudLiveMcValue)

        // Col 2: Live PnL
        val colPnl = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.15f)
        }
        colPnl.addView(makeLabel("Live PnL"))
        hudLivePnlValue = TextView(this).apply {
            text = "Flat (0 SOL)"
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
        }
        colPnl.addView(hudLivePnlValue)

        // Col 3: Multiple
        val colMult = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.85f)
        }
        colMult.addView(makeLabel("Multiple"))
        hudMultipleValue = TextView(this).apply {
            text = "1.00x"
            setTextColor(Color.parseColor("#22D3EE"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
        }
        colMult.addView(hudMultipleValue)

        metricsTopRow.addView(colMc)
        metricsTopRow.addView(colPnl)
        metricsTopRow.addView(colMult)

        // Divider
        val div = View(this).apply {
            setBackgroundColor(Color.parseColor("#1E293B"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply {
                topMargin = dp(6)
                bottomMargin = dp(6)
            }
        }

        // Second Metrics Row: Bought MC | Sell MC | Bag Left %
        val metricsSubRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 3f
        }

        hudBoughtMcValue = TextView(this).apply {
            text = "Bought: —"
            setTextColor(Color.parseColor("#38BDF8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.MONOSPACE
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        hudSellMcValue = TextView(this).apply {
            text = "Sell: $41.9M"
            setTextColor(Color.parseColor("#E2E8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        hudBagLeftValue = TextView(this).apply {
            text = "Bag: 0%"
            setTextColor(Color.parseColor("#34D399"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.MONOSPACE
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        metricsSubRow.addView(hudBoughtMcValue)
        metricsSubRow.addView(hudSellMcValue)
        metricsSubRow.addView(hudBagLeftValue)

        metricsBox.addView(metricsTopRow)
        metricsBox.addView(div)
        metricsBox.addView(metricsSubRow)

        // Instant Buy Header Row
        val buyHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(5) }
        }
        val buyHeaderTitle = TextView(this).apply {
            text = "INSTANT BUY (SOL)"
            setTextColor(Color.parseColor("#10B981"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        hudSolBalanceText = TextView(this).apply {
            text = "Bal: 10.00 SOL"
            setTextColor(Color.parseColor("#CBD5E1"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
        }
        buyHeaderRow.addView(buyHeaderTitle)
        buyHeaderRow.addView(hudSolBalanceText)

        buyButtonsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 4f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(10) }
        }

        // Instant Sell Header Row
        val sellHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(5) }
        }
        val sellHeaderTitle = TextView(this).apply {
            text = "INSTANT SELL (%)"
            setTextColor(Color.parseColor("#F43F5E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        hudFeeInfoText = TextView(this).apply {
            text = "Fee: 1% + 0.005 SOL"
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.MONOSPACE
        }
        sellHeaderRow.addView(sellHeaderTitle)
        sellHeaderRow.addView(hudFeeInfoText)

        sellButtonsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 4f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        }

        // Custom Partial Sell % Row + Hide-to-Pill Action
        val customSellRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        customSellPctInput = EditText(this).apply {
            hint = "Custom % (e.g. 30)"
            setText("30")
            setHintTextColor(Color.parseColor("#64748B"))
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = roundedBox("#090C14", "#334155", dp(8), dp(1))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = dp(6)
            }
            setOnClickListener { enableKeyboardFocus(true) }
        }

        val customSellBtn = TextView(this).apply {
            text = "Sell Custom %"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = roundedBox("#881337", "#F43F5E", dp(8), dp(1))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = dp(6) }
            setOnClickListener {
                val pct = customSellPctInput.text.toString().toDoubleOrNull() ?: 30.0
                enableKeyboardFocus(false)
                handleSellClick(pct)
            }
        }

        val hideToPillBtn = TextView(this).apply {
            text = "Watch Chart 👁"
            setTextColor(Color.parseColor("#090B10"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = roundedBox("#10B981", "#34D399", dp(8), dp(1))
            setOnClickListener { switchToMinimizedPill() }
        }

        customSellRow.addView(customSellPctInput)
        customSellRow.addView(customSellBtn)
        customSellRow.addView(hideToPillBtn)

        hudBody.addView(metricsBox)
        hudBody.addView(buyHeaderRow)
        hudBody.addView(buyButtonsRow)
        hudBody.addView(sellHeaderRow)
        hudBody.addView(sellButtonsRow)
        hudBody.addView(customSellRow)

        hudCard.addView(hudHeader)
        hudCard.addView(hudBody)

        rootContainer.addView(pillCard)
        rootContainer.addView(hudCard)

        // Touch Dragging for both Pill and HUD Header
        val dragTouchListener = object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).toInt()
                        val dy = (event.rawY - touchY).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        params.x = startX + dx
                        params.y = startY + dy
                        windowManager.updateViewLayout(rootContainer, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved && v == pillCard) {
                            switchToExpandedHud()
                        }
                        return true
                    }
                }
                return false
            }
        }

        pillCard.setOnTouchListener(dragTouchListener)
        hudHeader.setOnTouchListener(dragTouchListener)

        rebuildPresetButtons()
        refreshHudAndPillUI()
    }

    private fun rebuildPresetButtons() {
        buyButtonsRow.removeAllViews()
        val buys = TradeRepository.settings.buyPresets
        for (i in buys.indices) {
            val amt = buys[i]
            val btn = TextView(this).apply {
                text = "${amt} SOL"
                setTextColor(Color.parseColor("#34D399"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                typeface = Typeface.MONOSPACE
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(9), dp(4), dp(9))
                background = roundedBox("#06362D", "#10B981", dp(10), dp(1))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (i < buys.size - 1) rightMargin = dp(5)
                }
                setOnClickListener { handleBuyClick(amt) }
            }
            buyButtonsRow.addView(btn)
        }

        sellButtonsRow.removeAllViews()
        val sells = TradeRepository.settings.sellPresets
        for (i in sells.indices) {
            val pct = sells[i]
            val btn = TextView(this).apply {
                text = "${pct.toInt()}%"
                setTextColor(Color.parseColor("#FDA4AF"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                typeface = Typeface.MONOSPACE
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(9), dp(4), dp(9))
                background = roundedBox("#4C1D24", "#F43F5E", dp(10), dp(1))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (i < sells.size - 1) rightMargin = dp(5)
                }
                setOnClickListener { handleSellClick(pct) }
            }
            sellButtonsRow.addView(btn)
        }
    }

    private fun handleBuyClick(solAmount: Double) {
        val res = TradeRepository.executeBuy(currentToken, solAmount)
        res.onSuccess { pos ->
            Toast.makeText(
                this,
                "Bought $solAmount SOL of ${pos.symbol} @ ${Formatters.compactUsd(pos.entryMc)} MC",
                Toast.LENGTH_SHORT
            ).show()
            refreshHudAndPillUI()
        }.onFailure { err ->
            Toast.makeText(this, err.message ?: "Buy failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleSellClick(pct: Double) {
        val res = TradeRepository.executeSell(currentToken, pct)
        res.onSuccess { log ->
            val remMsg = if (log.remainingPctAfter > 0.0) {
                " (${log.remainingPctAfter.toInt()}% still running!)"
            } else {
                " (Position Closed)"
            }
            Toast.makeText(
                this,
                "Sold ${pct.toInt()}% ${log.symbol} @ ${Formatters.multX(log.multipleX)} • ${Formatters.solSigned(log.pnlSol)}$remMsg",
                Toast.LENGTH_SHORT
            ).show()
            refreshHudAndPillUI()
        }.onFailure { err ->
            Toast.makeText(this, err.message ?: "No position to sell", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pasteCaFromClipboard() {
        // Temporarily make window focusable to read Android 10+ clipboard reliably
        enableKeyboardFocus(true)
        mainHandler.postDelayed({
            try {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    val raw = clip.getItemAt(0).coerceToText(this).toString()
                    val ca = DexScreenerClient.extractSolanaCa(raw)
                    if (ca.length >= 20) {
                        TradeRepository.setActiveCa(ca)
                        Toast.makeText(this, "Loading CA: ${Formatters.shortCa(ca)}", Toast.LENGTH_SHORT).show()
                        Executors.newSingleThreadExecutor().execute {
                            val token = DexScreenerClient.fetchTokenSync(ca)
                            if (token != null) {
                                currentToken = token
                                TradeRepository.syncLiveTokenData(token)
                                mainHandler.post { refreshHudAndPillUI() }
                            }
                        }
                    } else {
                        Toast.makeText(this, "Copy a valid Solana Coin CA from fomo first", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (_: Throwable) {
            } finally {
                enableKeyboardFocus(false)
            }
        }, 120)
    }

    private fun enableKeyboardFocus(focusable: Boolean) {
        params.flags = if (focusable) {
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        windowManager.updateViewLayout(rootContainer, params)
        if (!focusable) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(rootContainer.windowToken, 0)
        }
    }

    private fun switchToMinimizedPill() {
        enableKeyboardFocus(false)
        hudCard.visibility = View.GONE
        pillCard.visibility = View.VISIBLE
        windowManager.updateViewLayout(rootContainer, params)
    }

    private fun switchToExpandedHud() {
        pillCard.visibility = View.GONE
        hudCard.visibility = View.VISIBLE
        rebuildPresetButtons()
        refreshHudAndPillUI()
        windowManager.updateViewLayout(rootContainer, params)
    }

    fun applyInstantScreenMc(screenMc: Double) {
        if (screenMc <= 0.0) return
        val oldMc = currentToken.marketCap.coerceAtLeast(1.0)
        val ratio = screenMc / oldMc
        val newPrice = (currentToken.priceUsd * ratio).coerceAtLeast(0.0000000001)
        currentToken = currentToken.copy(
            marketCap = screenMc,
            priceUsd = newPrice
        )
        TradeRepository.syncLiveTokenData(currentToken)
        mainHandler.post { refreshHudAndPillUI() }
    }

    private fun refreshHudAndPillUI() {
        val sym = if (currentToken.symbol.startsWith("$")) currentToken.symbol else "$${currentToken.symbol}"
        val mcStr = Formatters.compactUsd(currentToken.marketCap)

        hudTickerBadge.text = sym
        pillTickerText.text = sym
        hudLiveMcValue.text = mcStr
        hudSellMcValue.text = "Sell: $mcStr"
        hudSolBalanceText.text = String.format("Bal: %.2f SOL", TradeRepository.settings.solBalance)
        hudFeeInfoText.text = "Fee: ${TradeRepository.settings.platformFeePct}% + ${TradeRepository.settings.priorityFeeSol} SOL"

        val pos = TradeRepository.getPosition(currentToken.ca)
        if (pos != null && pos.tokensHeld > 0.0) {
            val pnlSol = TradeRepository.computeUnrealizedPnlSol(pos, currentToken.priceUsd)
            val pnlPct = if (pos.solInvested > 0.0) (pnlSol / pos.solInvested) * 100.0 else 0.0
            val multX = if (pos.entryMc > 0.0) (currentToken.marketCap / pos.entryMc) else 1.0
            val isProfit = pnlSol >= 0.0
            val pnlColor = Color.parseColor(if (isProfit) "#10B981" else "#F43F5E")

            val pnlFormatted = "${Formatters.solSigned(pnlSol)} (${Formatters.pctSigned(pnlPct)})"
            val multFormatted = Formatters.multX(multX)
            val boughtMcStr = Formatters.compactUsd(pos.entryMc)
            val remPctInt = pos.remainingPct.toInt()

            hudLivePnlValue.text = pnlFormatted
            hudLivePnlValue.setTextColor(pnlColor)
            hudMultipleValue.text = multFormatted
            hudBoughtMcValue.text = "Bought: $boughtMcStr"
            hudBagLeftValue.text = "Bag: $remPctInt% Left"

            pillPnlText.text = pnlFormatted
            pillPnlText.setTextColor(pnlColor)
            pillMultBadge.text = multFormatted
            pillSubText.text = "Bought $boughtMcStr → Now $mcStr • $remPctInt% Left"
        } else {
            hudLivePnlValue.text = "0.000 SOL"
            hudLivePnlValue.setTextColor(Color.parseColor("#94A3B8"))
            hudMultipleValue.text = "1.00x"
            hudBoughtMcValue.text = "Bought: —"
            hudBagLeftValue.text = "Bag: 0%"

            pillPnlText.text = mcStr
            pillPnlText.setTextColor(Color.parseColor("#10B981"))
            pillMultBadge.text = "FLAT"
            pillSubText.text = "No open trade • Tap pill to Buy/Sell"
        }
    }

    private fun makeLabel(text: String): TextView {
        return TextView(this).apply {
            this.text = text
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        }
    }

    private fun roundedBox(fillHex: String, strokeHex: String, radiusPx: Int, strokePx: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            setColor(Color.parseColor(fillHex))
            if (strokePx > 0) setStroke(strokePx, Color.parseColor(strokeHex))
        }
    }

    private fun roundedTopBox(fillHex: String, radiusPx: Int): GradientDrawable {
        val r = radiusPx.toFloat()
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            setColor(Color.parseColor(fillHex))
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun startForegroundServiceNotification() {
        val channelId = "pocketflip_native_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "PocketFlip Floating Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the PocketFlip floating bubble alive over fomo"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)

            val launchIntent = Intent(this, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                this,
                0,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = Notification.Builder(this, channelId)
                .setContentTitle("PocketFlip Floating Bubble Active")
                .setContentText("Hovering over fomo & Axiom • Tap to open controls")
                .setSmallIcon(android.R.drawable.sym_def_app_icon)
                .setContentIntent(pendingIntent)
                .build()

            try {
                if (Build.VERSION.SDK_INT >= 34) { // Android 14+ (UpsideDownCake)
                    startForeground(
                        101,
                        notification,
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                    )
                } else {
                    startForeground(101, notification)
                }
            } catch (err: Throwable) {
                try {
                    startForeground(101, notification)
                } catch (_: Throwable) {}
            }
        }
    }

    override fun onDestroy() {
        isRunning = false
        instance = null
        TradeRepository.removeListener(repoListener)
        poller?.shutdownNow()
        if (::rootContainer.isInitialized) {
            try {
                windowManager.removeView(rootContainer)
            } catch (_: Throwable) {}
        }
        super.onDestroy()
    }
}
