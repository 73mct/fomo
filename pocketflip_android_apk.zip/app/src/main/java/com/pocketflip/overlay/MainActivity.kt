package com.pocketflip.overlay

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var tabOverlaySection: LinearLayout
    private lateinit var tabJournalSection: LinearLayout
    private lateinit var tabSettingsSection: LinearLayout

    private lateinit var navBtnOverlay: TextView
    private lateinit var navBtnJournal: TextView
    private lateinit var navBtnSettings: TextView

    private lateinit var headerBalanceText: TextView
    private lateinit var overlayStatusText: TextView
    private lateinit var journalKpiSummaryText: TextView
    private lateinit var journalListContainer: LinearLayout
    private lateinit var activePositionsContainer: LinearLayout

    private val repoListener: () -> Unit = {
        mainHandler.post { refreshMainUI() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TradeRepository.init(this)
        window.statusBarColor = Color.parseColor("#090B10")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#090B10"))
        }

        // Top App Bar
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(Color.parseColor("#0D111A"))
        }

        val appLogo = TextView(this).apply {
            text = "PF"
            setTextColor(Color.parseColor("#090B10"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
            background = box("#10B981", "#34D399", dp(10), dp(1))
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) }
        }

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val titleText = TextView(this).apply {
            text = "PocketFlip Native"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subTitleText = TextView(this).apply {
            text = "Poco X6 Pro Floating fomo Paper Trader"
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        }
        titleCol.addView(titleText)
        titleCol.addView(subTitleText)

        headerBalanceText = TextView(this).apply {
            text = "10.000 SOL"
            setTextColor(Color.parseColor("#10B981"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = box("#111827", "#1E293B", dp(10), dp(1))
        }

        topBar.addView(appLogo)
        topBar.addView(titleCol)
        topBar.addView(headerBalanceText)

        // Navigation Row
        val navRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 3f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.parseColor("#0D111A"))
        }

        navBtnOverlay = makeNavTab("1. Bubble HUD", true) { switchTab(0) }
        navBtnJournal = makeNavTab("2. Trade Journal", false) { switchTab(1) }
        navBtnSettings = makeNavTab("3. Presets & Fees", false) { switchTab(2) }

        navRow.addView(navBtnOverlay)
        navRow.addView(navBtnJournal)
        navRow.addView(navBtnSettings)

        // Scrollable Body
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }

        val contentHolder = FrameLayout(this).apply {
            setPadding(dp(14), dp(14), dp(14), dp(28))
        }

        tabOverlaySection = buildOverlayControlTab()
        tabJournalSection = buildJournalTab()
        tabSettingsSection = buildSettingsTab()

        contentHolder.addView(tabOverlaySection)
        contentHolder.addView(tabJournalSection)
        contentHolder.addView(tabSettingsSection)
        scroll.addView(contentHolder)

        root.addView(topBar)
        root.addView(navRow)
        root.addView(scroll)

        setContentView(root)
        TradeRepository.addListener(repoListener)
        switchTab(0)
        refreshMainUI()
    }

    private fun buildOverlayControlTab(): LinearLayout {
        return LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL

            // Launch Card
            val launchCard = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(16), dp(16), dp(16))
                background = box("#111622", "#1E293B", dp(16), dp(1))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(14) }
            }

            overlayStatusText = TextView(this@MainActivity).apply {
                text = "Floating Bubble Status: Checking..."
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            }

            val desc = TextView(this@MainActivity).apply {
                text = "Tap 'Launch Floating Bubble' below, then open the fomo app. Copy any coin's CA inside fomo, tap 'Paste CA' on the floating HUD, click Buy, and tap '—' to collapse into the Live PnL Pill while watching fomo's chart!"
                setTextColor(Color.parseColor("#94A3B8"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setPadding(0, dp(6), 0, dp(14))
            }

            val startBtn = TextView(this@MainActivity).apply {
                text = "🚀 LAUNCH FLOATING BUBBLE OVER FOMO"
                setTextColor(Color.parseColor("#090B10"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(13), dp(12), dp(13))
                background = box("#10B981", "#34D399", dp(12), dp(1))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(8) }
                setOnClickListener { startBubbleServiceWithCheck() }
            }

            val stopBtn = TextView(this@MainActivity).apply {
                text = "Stop Floating Bubble"
                setTextColor(Color.parseColor("#FDA4AF"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = box("#3B1219", "#F43F5E", dp(12), dp(1))
                setOnClickListener {
                    stopService(Intent(this@MainActivity, OverlayService::class.java))
                    mainHandler.postDelayed({ refreshMainUI() }, 200)
                }
            }

            launchCard.addView(overlayStatusText)
            launchCard.addView(desc)
            launchCard.addView(startBtn)
            launchCard.addView(stopBtn)

            // Poco X6 Pro HyperOS Permissions Helper Card
            val permCard = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(14), dp(14), dp(14))
                background = box("#111622", "#1E293B", dp(16), dp(1))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(14) }
            }

            val permTitle = TextView(this@MainActivity).apply {
                text = "Poco X6 Pro (Xiaomi HyperOS) Setup Switches"
                setTextColor(Color.parseColor("#38BDF8"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            }

            val permSub = TextView(this@MainActivity).apply {
                text = "On Xiaomi HyperOS, enable 'Display over other apps' AND 'Display pop-up windows while running in the background' so the bubble stays visible over fomo."
                setTextColor(Color.parseColor("#94A3B8"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setPadding(0, dp(4), 0, dp(10))
            }

            val btnOverlayPerm = TextView(this@MainActivity).apply {
                text = "1. Open 'Display Over Other Apps' Permission"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = box("#1E293B", "#334155", dp(10), dp(1))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(6) }
                setOnClickListener {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")
                            )
                        )
                    }
                }
            }

            val btnHyperOsPerm = TextView(this@MainActivity).apply {
                text = "2. Enable 'Display pop-up windows in background' (Xiaomi HyperOS)"
                setTextColor(Color.parseColor("#38BDF8"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(12), dp(10), dp(12))
                background = box("#1E293B", "#38BDF8", dp(10), dp(1))
                setOnClickListener {
                    // Try to launch Xiaomi HyperOS / MIUI "Other Permissions" directly
                    var launched = false
                    try {
                        val miuiIntent = Intent("miui.intent.action.APP_PERM_EDITOR").apply {
                            setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
                            putExtra("extra_pkgname", packageName)
                        }
                        startActivity(miuiIntent)
                        launched = true
                    } catch (_: Throwable) {}
                    if (!launched) {
                        try {
                            val miuiIntent2 = Intent("miui.intent.action.APP_PERM_EDITOR").apply {
                                setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity")
                                putExtra("extra_pkgname", packageName)
                            }
                            startActivity(miuiIntent2)
                            launched = true
                        } catch (_: Throwable) {}
                    }
                    if (!launched) {
                        startActivity(
                            Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:$packageName")
                            )
                        )
                    }
                }
            }

            val btnScreenSyncPerm = TextView(this@MainActivity).apply {
                text = "⚡ 3. Enable 0ms Instant fomo Screen-Sync (Reads MC Directly Off Screen)"
                setTextColor(Color.parseColor("#090B10"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(12), dp(10), dp(12))
                background = box("#38BDF8", "#7DD3FC", dp(10), dp(1))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(6) }
                setOnClickListener {
                    Toast.makeText(
                        this@MainActivity,
                        "Tap 'Downloaded apps' -> 'PocketFlip Instant fomo Screen Sync' -> Enable!",
                        Toast.LENGTH_LONG
                    ).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }

            permCard.addView(permTitle)
            permCard.addView(permSub)
            permCard.addView(btnOverlayPerm)
            permCard.addView(btnHyperOsPerm)
            permCard.addView(btnScreenSyncPerm)

            // Active Open Positions Card
            val posCard = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(14), dp(14), dp(14))
                background = box("#111622", "#1E293B", dp(16), dp(1))
            }
            val posTitle = TextView(this@MainActivity).apply {
                text = "Active Open Positions"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                setPadding(0, 0, 0, dp(8))
            }
            activePositionsContainer = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
            }
            posCard.addView(posTitle)
            posCard.addView(activePositionsContainer)

            addView(launchCard)
            addView(permCard)
            addView(posCard)
        }
    }

    private fun buildJournalTab(): LinearLayout {
        return LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE

            val kpiCard = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(14), dp(14), dp(14))
                background = box("#111622", "#1E293B", dp(16), dp(1))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(12) }
            }

            val kpiHeader = TextView(this@MainActivity).apply {
                text = "Lifetime Paper Trading Performance"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            }

            journalKpiSummaryText = TextView(this@MainActivity).apply {
                text = "Realized PnL: +0.000 SOL • Win Rate: 0% • Best X: 0.00x"
                setTextColor(Color.parseColor("#10B981"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.MONOSPACE
                setPadding(0, dp(6), 0, dp(10))
            }

            val actionsRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
            }

            val exportBtn = TextView(this@MainActivity).apply {
                text = "Share / Export CSV"
                setTextColor(Color.parseColor("#38BDF8"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                background = box("#1E293B", "#334155", dp(8), dp(1))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { rightMargin = dp(8) }
                setOnClickListener { shareJournalCsv() }
            }

            val clearBtn = TextView(this@MainActivity).apply {
                text = "Clear Log"
                setTextColor(Color.parseColor("#FDA4AF"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                background = box("#3B1219", "#F43F5E", dp(8), dp(1))
                setOnClickListener {
                    TradeRepository.clearJournal()
                    Toast.makeText(this@MainActivity, "Cleared trade history", Toast.LENGTH_SHORT).show()
                }
            }

            actionsRow.addView(exportBtn)
            actionsRow.addView(clearBtn)

            kpiCard.addView(kpiHeader)
            kpiCard.addView(journalKpiSummaryText)
            kpiCard.addView(actionsRow)

            journalListContainer = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
            }

            addView(kpiCard)
            addView(journalListContainer)
        }
    }

    private fun buildSettingsTab(): LinearLayout {
        val s = TradeRepository.settings
        return LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = box("#111622", "#1E293B", dp(16), dp(1))

            val title = TextView(this@MainActivity).apply {
                text = "Configure Floating Bubble Buttons & Fees"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                setPadding(0, 0, 0, dp(12))
            }
            addView(title)

            val balInput = addLabeledNumberInput(this, "Paper Wallet SOL Balance", s.solBalance.toString())
            val feeInput = addLabeledNumberInput(this, "Platform Fee % (fomo / Axiom default 1.0%)", s.platformFeePct.toString())
            val prioInput = addLabeledNumberInput(this, "Priority / Bribe Fee (SOL per tx)", s.priorityFeeSol.toString())
            val slipInput = addLabeledNumberInput(this, "Simulated Slippage %", s.slippagePct.toString())

            val buyInput = addLabeledTextInput(
                this,
                "4 Quick-Buy SOL Buttons (comma-separated)",
                s.buyPresets.joinToString(", ")
            )
            val sellInput = addLabeledTextInput(
                this,
                "4 Quick-Sell % Buttons (comma-separated, e.g. 25, 30, 50, 100)",
                s.sellPresets.map { it.toInt() }.joinToString(", ")
            )

            val saveBtn = TextView(this@MainActivity).apply {
                text = "Save Settings & Update Floating Bubble"
                setTextColor(Color.parseColor("#090B10"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = box("#10B981", "#34D399", dp(12), dp(1))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(10) }
                setOnClickListener {
                    val newBal = balInput.text.toString().toDoubleOrNull() ?: s.solBalance
                    val newFee = feeInput.text.toString().toDoubleOrNull() ?: s.platformFeePct
                    val newPrio = prioInput.text.toString().toDoubleOrNull() ?: s.priorityFeeSol
                    val newSlip = slipInput.text.toString().toDoubleOrNull() ?: s.slippagePct

                    val parsedBuys = buyInput.text.toString().split(",")
                        .mapNotNull { it.trim().toDoubleOrNull() }
                    val parsedSells = sellInput.text.toString().split(",")
                        .mapNotNull { it.trim().toDoubleOrNull() }

                    val finalBuys = if (parsedBuys.size == 4) parsedBuys else s.buyPresets
                    val finalSells = if (parsedSells.size == 4) parsedSells else s.sellPresets

                    TradeRepository.updateSettings(
                        newBalance = newBal,
                        platformFeePct = newFee,
                        priorityFeeSol = newPrio,
                        slippagePct = newSlip,
                        buyPresets = finalBuys,
                        sellPresets = finalSells
                    )
                    Toast.makeText(this@MainActivity, "Saved settings! Floating HUD updated.", Toast.LENGTH_SHORT).show()
                }
            }
            addView(saveBtn)
        }
    }

    private fun refreshMainUI() {
        val s = TradeRepository.settings
        headerBalanceText.text = String.format("%.3f SOL", s.solBalance)

        overlayStatusText.text = if (OverlayService.isRunning) {
            "🟢 Floating Bubble is ACTIVE (Hovering over fomo)"
        } else {
            "⚪ Floating Bubble is Stopped"
        }

        // Render Open Positions
        activePositionsContainer.removeAllViews()
        val openList = TradeRepository.getAllPositions()
        if (openList.isEmpty()) {
            activePositionsContainer.addView(TextView(this@MainActivity).apply {
                text = "No open positions right now. Launch the bubble over fomo to start paper trading!"
                setTextColor(Color.parseColor("#64748B"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            })
        } else {
            for (pos in openList) {
                val pnlSol = TradeRepository.computeUnrealizedPnlSol(pos, pos.lastPriceUsd)
                val multX = if (pos.entryMc > 0.0) (pos.lastMc / pos.entryMc) else 1.0
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                    background = box("#090C14", "#1E293B", dp(10), dp(1))
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = dp(8) }
                }
                val info = TextView(this@MainActivity).apply {
                    text = "${pos.name} (${pos.symbol}) • ${pos.remainingPct.roundToInt()}% Left\nBought: ${Formatters.compactUsd(pos.entryMc)} → Now: ${Formatters.compactUsd(pos.lastMc)} (${Formatters.multX(multX)})"
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                    typeface = Typeface.MONOSPACE
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val pnlView = TextView(this@MainActivity).apply {
                    text = Formatters.solSigned(pnlSol)
                    setTextColor(Color.parseColor(if (pnlSol >= 0.0) "#10B981" else "#F43F5E"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    typeface = Typeface.MONOSPACE
                    setTypeface(typeface, Typeface.BOLD)
                }
                row.addView(info)
                row.addView(pnlView)
                activePositionsContainer.addView(row)
            }
        }

        // Render Journal Entries
        val logs = TradeRepository.getJournal()
        var totalPnl = 0.0
        var wins = 0
        var bestX = 0.0
        var totalHold = 0L
        for (l in logs) {
            totalPnl += l.pnlSol
            if (l.pnlSol >= 0.0) wins++
            if (l.multipleX > bestX) bestX = l.multipleX
            totalHold += l.holdDurationMs
        }
        val winRate = if (logs.isNotEmpty()) (wins * 100) / logs.size else 0
        val avgHold = if (logs.isNotEmpty()) totalHold / logs.size else 0L
        journalKpiSummaryText.text =
            "Net PnL: ${Formatters.solSigned(totalPnl)} • Win Rate: $winRate% (${wins}/${logs.size})\nBest Multiple: ${Formatters.multX(bestX)} • Avg Hold: ${Formatters.duration(avgHold)}"

        journalListContainer.removeAllViews()
        if (logs.isEmpty()) {
            journalListContainer.addView(TextView(this@MainActivity).apply {
                text = "No closed or partial sells yet. Every 30% partial sell or 100% exit from the floating bubble is logged here with Coin Icon, Ticker, CA, Bought MC, Sold MC, X Multiple, and Hold Duration."
                setTextColor(Color.parseColor("#64748B"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setPadding(dp(8), dp(8), dp(8), dp(8))
            })
        } else {
            for (item in logs) {
                journalListContainer.addView(buildJournalItemCard(item))
            }
        }
    }

    private fun buildJournalItemCard(item: ClosedTradeLog): View {
        val card = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = box("#111622", "#1E293B", dp(14), dp(1))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        }

        val topRow = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val iconView = ImageView(this@MainActivity).apply {
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) }
            setImageResource(android.R.drawable.sym_def_app_icon)
        }
        if (item.imageUrl.isNotEmpty()) {
            DexScreenerClient.loadTokenBitmap(item.imageUrl) { bmp ->
                if (bmp != null) mainHandler.post { iconView.setImageBitmap(bmp) }
            }
        }

        val titleCol = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val nameLine = TextView(this@MainActivity).apply {
            text = "${item.name} (${item.symbol}) • Sold ${item.soldPct.roundToInt()}%"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        }

        val caLine = TextView(this@MainActivity).apply {
            text = "CA: ${Formatters.shortCa(item.ca)} (Tap to copy) • Held: ${Formatters.duration(item.holdDurationMs)}"
            setTextColor(Color.parseColor("#38BDF8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.MONOSPACE
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Solana CA", item.ca))
                Toast.makeText(this@MainActivity, "Copied CA: ${item.ca}", Toast.LENGTH_SHORT).show()
            }
        }

        titleCol.addView(nameLine)
        titleCol.addView(caLine)

        val pnlBadge = TextView(this@MainActivity).apply {
            text = "${Formatters.solSigned(item.pnlSol)}\n(${Formatters.multX(item.multipleX)})"
            setTextColor(Color.parseColor(if (item.pnlSol >= 0.0) "#10B981" else "#F43F5E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.END
        }

        topRow.addView(iconView)
        topRow.addView(titleCol)
        topRow.addView(pnlBadge)

        val mcRow = TextView(this@MainActivity).apply {
            text = "Bought MC: ${Formatters.compactUsd(item.boughtMc)}  →  Sold MC: ${Formatters.compactUsd(item.soldMc)}  •  Remaining Bag: ${item.remainingPctAfter.roundToInt()}%"
            setTextColor(Color.parseColor("#CBD5E1"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
            setPadding(0, dp(8), 0, 0)
        }

        card.addView(topRow)
        card.addView(mcRow)
        return card
    }

    private fun startBubbleServiceWithCheck() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Please grant 'Display over other apps' permission for PocketFlip first",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }
        val svc = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(svc)
        } else {
            startService(svc)
        }
        Toast.makeText(this, "PocketFlip Bubble Launched! Open fomo now.", Toast.LENGTH_SHORT).show()
        mainHandler.postDelayed({ refreshMainUI() }, 250)
    }

    private fun shareJournalCsv() {
        val logs = TradeRepository.getJournal()
        if (logs.isEmpty()) {
            Toast.makeText(this, "No trades in journal yet", Toast.LENGTH_SHORT).show()
            return
        }
        val sb = StringBuilder("CoinName,Ticker,CA,BoughtMC,SoldMC,MultipleX,SoldPct,NetPnlSol,HoldDuration\n")
        for (l in logs) {
            sb.append("\"${l.name}\",\"${l.symbol}\",\"${l.ca}\",${l.boughtMc},${l.soldMc},${l.multipleX},${l.soldPct},${l.pnlSol},\"${Formatters.duration(l.holdDurationMs)}\"\n")
        }
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "PocketFlip Trade Journal CSV")
            putExtra(Intent.EXTRA_TEXT, sb.toString())
        }
        startActivity(Intent.createChooser(sendIntent, "Export PocketFlip Trade Journal"))
    }

    private fun switchTab(idx: Int) {
        tabOverlaySection.visibility = if (idx == 0) View.VISIBLE else View.GONE
        tabJournalSection.visibility = if (idx == 1) View.VISIBLE else View.GONE
        tabSettingsSection.visibility = if (idx == 2) View.VISIBLE else View.GONE

        val tabs = listOf(navBtnOverlay, navBtnJournal, navBtnSettings)
        for (i in tabs.indices) {
            if (i == idx) {
                tabs[i].setTextColor(Color.parseColor("#090B10"))
                tabs[i].background = box("#10B981", "#34D399", dp(10), dp(1))
            } else {
                tabs[i].setTextColor(Color.parseColor("#CBD5E1"))
                tabs[i].background = box("#1E293B", "#334155", dp(10), dp(1))
            }
        }
        refreshMainUI()
    }

    private fun makeNavTab(title: String, active: Boolean, onClick: () -> Unit): TextView {
        return TextView(this@MainActivity).apply {
            text = title
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(9), dp(6), dp(9))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                leftMargin = dp(3)
                rightMargin = dp(3)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun addLabeledNumberInput(parent: LinearLayout, label: String, initial: String): EditText {
        parent.addView(TextView(this@MainActivity).apply {
            text = label
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setPadding(0, dp(6), 0, dp(4))
        })
        val input = EditText(this@MainActivity).apply {
            setText(initial)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.MONOSPACE
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = box("#090C14", "#334155", dp(8), dp(1))
        }
        parent.addView(input)
        return input
    }

    private fun addLabeledTextInput(parent: LinearLayout, label: String, initial: String): EditText {
        parent.addView(TextView(this@MainActivity).apply {
            text = label
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setPadding(0, dp(6), 0, dp(4))
        })
        val input = EditText(this@MainActivity).apply {
            setText(initial)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.MONOSPACE
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = box("#090C14", "#334155", dp(8), dp(1))
        }
        parent.addView(input)
        return input
    }

    private fun box(fillHex: String, strokeHex: String, radiusPx: Int, strokePx: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            setColor(Color.parseColor(fillHex))
            if (strokePx > 0) setStroke(strokePx, Color.parseColor(strokeHex))
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    override fun onDestroy() {
        TradeRepository.removeListener(repoListener)
        super.onDestroy()
    }
}
