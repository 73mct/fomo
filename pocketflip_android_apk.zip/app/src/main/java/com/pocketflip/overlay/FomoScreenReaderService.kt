package com.pocketflip.overlay

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs

class FomoScreenReaderService : AccessibilityService() {

    companion object {
        @Volatile
        var isConnected: Boolean = false

        @Volatile
        var lastScreenMc: Double = 0.0

        @Volatile
        var lastScreenUpdateMs: Long = 0L

        private val mcValueRegex = Regex("\\$\\s*([0-9]+(?:\\.[0-9]+)?)\\s*([KMBkmb])")
    }

    private data class ScreenTextNode(
        val text: String,
        val rect: Rect
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        isConnected = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: ""
        // Never scan our own overlay window
        if (pkg == packageName || pkg.contains("pocketflip")) return

        val root = try {
            rootInActiveWindow
        } catch (_: Throwable) {
            null
        } ?: return

        try {
            val nodes = ArrayList<ScreenTextNode>(64)
            collectTextNodes(root, nodes, 0)
            if (nodes.isEmpty()) return

            var foundMc = 0.0

            // Strategy 1: Look for node labeled "Market cap" / "Mkt Cap" (exact layout of fomo app)
            for (i in nodes.indices) {
                val t = nodes[i].text
                if (t.contains("Market cap", ignoreCase = true) || t.contains("Mkt Cap", ignoreCase = true)) {
                    // Check if same node has "$109.8K Market cap"
                    val inlineMc = parseMcString(t)
                    if (inlineMc > 0.0) {
                        foundMc = inlineMc
                        break
                    }
                    // Otherwise find the closest "$XX.XK / $XX.XM" node right above or before "Market cap"
                    val labelRect = nodes[i].rect
                    var bestCandidate = 0.0
                    var bestDist = Int.MAX_VALUE

                    for (j in nodes.indices) {
                        if (i == j) continue
                        val candMc = parseMcString(nodes[j].text)
                        if (candMc >= 500.0) {
                            val r = nodes[j].rect
                            val dy = abs(labelRect.top - r.bottom)
                            val dx = abs(labelRect.centerX() - r.centerX())
                            val dist = dy * 2 + dx
                            if (dist < bestDist && dy < 300) {
                                bestDist = dist
                                bestCandidate = candMc
                            }
                        }
                    }

                    if (bestCandidate > 0.0) {
                        foundMc = bestCandidate
                        break
                    }
                    // Fallback to immediate previous node in hierarchy
                    if (i > 0) {
                        val prevMc = parseMcString(nodes[i - 1].text)
                        if (prevMc >= 500.0) {
                            foundMc = prevMc
                            break
                        }
                    }
                }
            }

            if (foundMc >= 500.0) {
                lastScreenMc = foundMc
                lastScreenUpdateMs = System.currentTimeMillis()
                OverlayService.onInstantScreenMcDetected(foundMc)
            }
        } catch (_: Throwable) {
        }
    }

    private fun collectTextNodes(node: AccessibilityNodeInfo?, out: MutableList<ScreenTextNode>, depth: Int) {
        if (node == null || depth > 28 || out.size > 160) return
        val rawText = node.text?.toString()?.trim()
        if (!rawText.isNullOrEmpty() && rawText.length <= 48) {
            val r = Rect()
            node.getBoundsInScreen(r)
            out.add(ScreenTextNode(rawText, r))
        }
        val count = node.childCount
        for (i in 0 until count) {
            val child = try {
                node.getChild(i)
            } catch (_: Throwable) {
                null
            }
            if (child != null) {
                collectTextNodes(child, out, depth + 1)
            }
        }
    }

    private fun parseMcString(text: String): Double {
        val m = mcValueRegex.find(text.replace(",", "")) ?: return 0.0
        val num = m.groupValues[1].toDoubleOrNull() ?: return 0.0
        val suffix = m.groupValues[2].uppercase()
        val mult = when (suffix) {
            "K" -> 1_000.0
            "M" -> 1_000_000.0
            "B" -> 1_000_000_000.0
            else -> 1.0
        }
        return num * mult
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        isConnected = false
        super.onDestroy()
    }
}
