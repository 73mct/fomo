package com.pocketflip.overlay

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

object DexScreenerClient {
    private val imageExecutor = Executors.newFixedThreadPool(2)
    private val bitmapCache = object : LruCache<String, Bitmap>(32) {}
    private val cachedPairAddressMap = ConcurrentHashMap<String, String>()
    private val base58Regex = Regex("[1-9A-HJ-NP-Za-km-z]{32,44}")

    fun extractSolanaCa(rawClipboard: String): String {
        val trimmed = rawClipboard.trim()
        val match = base58Regex.find(trimmed)
        return match?.value ?: trimmed
    }

    fun fetchTokenSync(rawCa: String): TokenInfo? {
        val ca = extractSolanaCa(rawCa)
        if (ca.length < 20) return null

        val cachedPair = cachedPairAddressMap[ca]
        if (!cachedPair.isNullOrEmpty()) {
            val byPair = fetchByPairAddress(cachedPair, ca)
            if (byPair != null) return byPair
        }

        val directSolanaUrl = "https://api.dexscreener.com/token-pairs/v1/solana/$ca"
        val fromDirect = fetchFromEndpoint(directSolanaUrl, ca, isArray = true)
        if (fromDirect != null) return fromDirect

        val fallbackUrl = "https://api.dexscreener.com/latest/dex/tokens/${URLEncoder.encode(ca, "UTF-8")}"
        return fetchFromEndpoint(fallbackUrl, ca, isArray = false)
    }

    private fun fetchByPairAddress(pairAddress: String, ca: String): TokenInfo? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://api.dexscreener.com/latest/dex/pairs/solana/$pairAddress")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 2500
                readTimeout = 2500
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "PocketFlip-Turbo/2.1")
                setRequestProperty("Connection", "Keep-Alive")
            }
            if (conn.responseCode != 200) return null
            val raw = conn.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(raw)
            val pair = root.optJSONObject("pair") ?: return null
            parsePairObject(pair, ca)
        } catch (_: Throwable) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun fetchFromEndpoint(endpoint: String, originalCa: String, isArray: Boolean): TokenInfo? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(endpoint)
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 2800
                readTimeout = 2800
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "PocketFlip-Turbo/2.1")
                setRequestProperty("Connection", "Keep-Alive")
            }
            if (conn.responseCode != 200) return null
            val raw = conn.inputStream.bufferedReader().use { it.readText() }

            val pairsArray: JSONArray? = if (isArray) {
                JSONArray(raw)
            } else {
                JSONObject(raw).optJSONArray("pairs")
            }

            if (pairsArray == null || pairsArray.length() == 0) return null

            var bestPair: JSONObject? = null
            var maxLiq = -1.0

            for (i in 0 until pairsArray.length()) {
                val p = pairsArray.optJSONObject(i) ?: continue
                val chain = p.optString("chainId")
                if (chain.isNotEmpty() && chain != "solana") continue
                val liq = p.optJSONObject("liquidity")?.optDouble("usd", 0.0) ?: 0.0
                if (liq > maxLiq || bestPair == null) {
                    maxLiq = liq
                    bestPair = p
                }
            }

            val chosen = bestPair ?: pairsArray.optJSONObject(0) ?: return null
            val pairAddress = chosen.optString("pairAddress")
            if (pairAddress.isNotEmpty()) {
                cachedPairAddressMap[originalCa] = pairAddress
            }
            parsePairObject(chosen, originalCa)
        } catch (_: Throwable) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun parsePairObject(pair: JSONObject, originalCa: String): TokenInfo? {
        val baseToken = pair.optJSONObject("baseToken") ?: return null
        val name = baseToken.optString("name", "Solana Token")
        val symbol = baseToken.optString("symbol", "TOKEN")
        val address = baseToken.optString("address", originalCa)

        val priceUsd = pair.optString("priceUsd", "0.0").toDoubleOrNull() ?: 0.00001
        val priceNative = pair.optString("priceNative", "0.0").toDoubleOrNull() ?: 0.0
        val solUsd = if (priceNative > 0.0 && priceUsd > 0.0) {
            val implied = priceUsd / priceNative
            if (implied in 10.0..2000.0) implied else TradeRepository.settings.solUsdPrice
        } else {
            TradeRepository.settings.solUsdPrice
        }

        val mc = when {
            pair.has("marketCap") && !pair.isNull("marketCap") -> pair.optDouble("marketCap", priceUsd * 1_000_000_000.0)
            pair.has("fdv") && !pair.isNull("fdv") -> pair.optDouble("fdv", priceUsd * 1_000_000_000.0)
            else -> priceUsd * 1_000_000_000.0
        }

        val vol24 = pair.optJSONObject("volume")?.optDouble("h24", 0.0) ?: 0.0
        val liqUsd = pair.optJSONObject("liquidity")?.optDouble("usd", 0.0) ?: 0.0
        val imageUrl = pair.optJSONObject("info")?.optString("imageUrl", "") ?: ""

        return TokenInfo(
            ca = address,
            name = name,
            symbol = symbol,
            priceUsd = priceUsd,
            solUsdPrice = solUsd,
            marketCap = mc,
            liquidityUsd = liqUsd,
            volume24h = vol24,
            imageUrl = imageUrl
        )
    }

    fun loadTokenBitmap(url: String, onLoaded: (Bitmap?) -> Unit) {
        if (url.isEmpty()) {
            onLoaded(null)
            return
        }
        val cached = bitmapCache.get(url)
        if (cached != null) {
            onLoaded(cached)
            return
        }
        imageExecutor.execute {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 3000
                    readTimeout = 3000
                }
                if (conn.responseCode == 200) {
                    val bmp = BitmapFactory.decodeStream(conn.inputStream)
                    if (bmp != null) bitmapCache.put(url, bmp)
                    onLoaded(bmp)
                    return@execute
                }
            } catch (_: Throwable) {
            } finally {
                conn?.disconnect()
            }
            onLoaded(null)
        }
    }
}
