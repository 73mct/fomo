package com.pocketflip.overlay

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

object DexScreenerClient {
    private val imageExecutor = Executors.newFixedThreadPool(2)
    private val bitmapCache = object : LruCache<String, Bitmap>(24) {}
    private val base58Regex = Regex("[1-9A-HJ-NP-Za-km-z]{32,44}")

    fun extractSolanaCa(rawClipboard: String): String {
        val trimmed = rawClipboard.trim()
        val match = base58Regex.find(trimmed)
        return match?.value ?: trimmed
    }

    fun fetchTokenSync(rawCa: String): TokenInfo? {
        val ca = extractSolanaCa(rawCa)
        if (ca.isEmpty()) return null

        var conn: HttpURLConnection? = null
        return try {
            val encoded = URLEncoder.encode(ca, "UTF-8")
            val url = URL("https://api.dexscreener.com/latest/dex/tokens/$encoded")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "PocketFlip-Android/2.0")
            }

            if (conn.responseCode != 200) return null
            val sb = StringBuilder()
            BufferedReader(InputStreamReader(conn.inputStream)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    sb.append(line)
                }
            }

            val root = JSONObject(sb.toString())
            val pairs = root.optJSONArray("pairs") ?: return null
            if (pairs.length() == 0) return null

            var chosen = pairs.getJSONObject(0)
            for (i in 0 until pairs.length()) {
                val candidate = pairs.getJSONObject(i)
                if (candidate.optString("chainId") == "solana") {
                    chosen = candidate
                    break
                }
            }

            val baseToken = chosen.optJSONObject("baseToken") ?: return null
            val name = baseToken.optString("name", "Solana Token")
            val symbol = baseToken.optString("symbol", "TOKEN")
            val address = baseToken.optString("address", ca)

            val priceUsd = chosen.optString("priceUsd", "0.0").toDoubleOrNull() ?: 0.00001
            val priceNative = chosen.optString("priceNative", "0.0").toDoubleOrNull() ?: 0.0
            val solUsd = if (priceNative > 0.0 && priceUsd > 0.0) {
                val implied = priceUsd / priceNative
                if (implied in 10.0..2000.0) implied else TradeRepository.settings.solUsdPrice
            } else {
                TradeRepository.settings.solUsdPrice
            }

            val mc = if (chosen.has("marketCap") && !chosen.isNull("marketCap")) {
                chosen.optDouble("marketCap", priceUsd * 1_000_000_000.0)
            } else {
                chosen.optDouble("fdv", priceUsd * 1_000_000_000.0)
            }

            val volObj = chosen.optJSONObject("volume")
            val vol24 = volObj?.optDouble("h24", 0.0) ?: 0.0
            val liqObj = chosen.optJSONObject("liquidity")
            val liqUsd = liqObj?.optDouble("usd", 0.0) ?: 0.0
            val infoObj = chosen.optJSONObject("info")
            val imageUrl = infoObj?.optString("imageUrl", "") ?: ""

            TokenInfo(
                ca = address,
                name = name,
                symbol = symbol,
                priceUsd = priceUsd,
                solUsdPrice = solUsd,
                marketCap = mc,
                liquidityUsd = liqUsd,
                volume24h = vol24,
                imageUrl = imageUrl
            )
        } catch (_: Throwable) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    fun loadTokenBitmap(url: String, onLoaded: (Bitmap?) -> Unit) {
        if (url.isEmpty()) {
            onLoaded(null)
            return
        }
        val cached = bitmapCache.get(url)
        if (cached != null) {
            onLoaded(cached)
            return
        }
        imageExecutor.execute {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 4000
                    readTimeout = 4000
                }
                if (conn.responseCode == 200) {
                    val bmp = BitmapFactory.decodeStream(conn.inputStream)
                    if (bmp != null) {
                        bitmapCache.put(url, bmp)
                    }
                    onLoaded(bmp)
                    return@execute
                }
            } catch (_: Throwable) {
            } finally {
                conn?.disconnect()
            }
            onLoaded(null)
        }
    }
}
