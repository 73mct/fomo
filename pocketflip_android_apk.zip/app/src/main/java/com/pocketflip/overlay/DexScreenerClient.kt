package com.pocketflip.overlay

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.LruCache
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

object DexScreenerClient {
    private val imageExecutor = Executors.newFixedThreadPool(2)
    private val bitmapCache = object : LruCache<String, Bitmap>(32) {}
    private val base58Regex = Regex("[1-9A-HJ-NP-Za-km-z]{32,44}")
    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
    private const val WSOL_MINT = "So11111111111111111111111111111111111111112"
    private const val SPL_TOKEN_PROGRAM = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
    private const val TOKEN_2022_PROGRAM = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
    private const val RAYDIUM_V4_PROGRAM = "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8"
    private const val PUMPFUN_PROGRAM = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P"

    // Persistent HTTP/2 & WebSocket client (zero TCP/TLS handshake overhead on subsequent polls!)
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(2500, TimeUnit.MILLISECONDS)
        .readTimeout(2500, TimeUnit.MILLISECONDS)
        .writeTimeout(2500, TimeUnit.MILLISECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val SOLANA_HTTP_RPCS = arrayOf(
        "https://solana-rpc.publicnode.com",
        "https://api.mainnet-beta.solana.com"
    )
    private val SOLANA_WS_RPCS = arrayOf(
        "wss://solana-rpc.publicnode.com",
        "wss://api.mainnet-beta.solana.com"
    )
    private val rpcIndex = AtomicInteger(0)

    private enum class PoolKind {
        PUMPFUN_CURVE,
        DUAL_SPL_VAULTS
    }

    private data class LivePoolConfig(
        val ca: String,
        val pairAddress: String,
        val kind: PoolKind,
        val tokenVault: String,
        val solVault: String,
        var baseRatio: Double,
        var baseMc: Double,
        var basePriceUsd: Double,
        @Volatile var latestTokenReserve: Double = 0.0,
        @Volatile var latestSolReserve: Double = 0.0
    )

    private val poolConfigMap = ConcurrentHashMap<String, LivePoolConfig>()
    private val tokenMetaMap = ConcurrentHashMap<String, TokenInfo>()
    private val lastRealtimeUpdateMs = ConcurrentHashMap<String, Long>()
    private val lastFallbackPollMs = ConcurrentHashMap<String, Long>()

    @Volatile
    private var activeSolanaWebSocket: WebSocket? = null

    @Volatile
    private var subscribedCa: String = ""

    fun extractSolanaCa(rawClipboard: String): String {
        val trimmed = rawClipboard.trim()
        val match = base58Regex.find(trimmed)
        return match?.value ?: trimmed
    }

    /**
     * Called ONCE when a new CA is pasted/selected, or every 30s solely to refresh SOL/USD reference.
     * NEVER overwrites live on-chain Market Cap once the live stream is running!
     */
    fun fetchInitialTokenMetadata(rawCa: String, onRealtimeUpdate: (TokenInfo) -> Unit): TokenInfo? {
        val ca = extractSolanaCa(rawCa)
        if (ca.length < 20) return null

        val existing = tokenMetaMap[ca]
        if (existing != null && poolConfigMap.containsKey(ca)) {
            ensureWebSocketsRunning(ca, onRealtimeUpdate)
            return existing
        }

        val t = System.currentTimeMillis()
        val directUrl = "https://api.dexscreener.com/token-pairs/v1/solana/$ca?_t=$t"
        val pairObj = fetchBestSolanaPairJson(directUrl, isArray = true)
            ?: fetchBestSolanaPairJson("https://api.dexscreener.com/latest/dex/tokens/$ca?_t=$t", isArray = false)
            ?: return existing

        val parsed = parsePairToTokenInfo(pairObj, ca) ?: return existing
        val pairAddress = pairObj.optString("pairAddress", "")

        tokenMetaMap[ca] = parsed
        tokenMetaMap[parsed.ca] = parsed

        if (pairAddress.isNotEmpty()) {
            initOnChainPoolForPair(parsed.ca, pairAddress, parsed)
        }
        ensureWebSocketsRunning(parsed.ca, onRealtimeUpdate)
        return parsed
    }

    /**
     * Returns the most recent on-chain metadata. WebSocket account notifications are primary;
     * HTTP RPC is used only as a recovery fallback when the stream is quiet.
     */
    fun pollLiveOnChainPrice(rawCa: String, onRealtimeUpdate: (TokenInfo) -> Unit): TokenInfo? {
        val ca = extractSolanaCa(rawCa)
        if (ca.length < 20) return null

        val meta = tokenMetaMap[ca] ?: return fetchInitialTokenMetadata(ca, onRealtimeUpdate)
        ensureWebSocketsRunning(ca, onRealtimeUpdate)

        // WebSocket is the primary feed. Use RPC polling only as a recovery fallback
        // when no account notification has arrived recently.
        val now = System.currentTimeMillis()
        val lastPush = lastRealtimeUpdateMs[ca] ?: 0L
        if (now - lastPush < 5_000L) return meta
        val lastFallback = lastFallbackPollMs[ca] ?: 0L
        if (now - lastFallback < 3_000L) return meta
        lastFallbackPollMs[ca] = now

        val cfg = poolConfigMap[ca]
        if (cfg == null) {
            return meta
        }

        return when (cfg.kind) {
            PoolKind.PUMPFUN_CURVE -> pollPumpFunBondingCurve(cfg, meta)
            PoolKind.DUAL_SPL_VAULTS -> pollDualSplVaults(cfg, meta)
        }
    }

    /**
     * Decodes Pump.fun Bonding Curve account (`pairAddress`) bytes 8..23:
     * bytes 8..15  = virtualTokenReserves (u64 LE, 6 decimals)
     * bytes 16..23 = virtualSolReserves   (u64 LE, 9 decimals)
     * Price in SOL = (virtualSolReserves / 1e9) / (virtualTokenReserves / 1e6)
     * Market Cap USD = Price in SOL * 1,000,000,000 * solUsdPrice
     */
    private fun pollPumpFunBondingCurve(cfg: LivePoolConfig, meta: TokenInfo): TokenInfo? {
        val reqObj = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("id", 1)
            put("method", "getAccountInfo")
            put("params", JSONArray().apply {
                put(cfg.pairAddress)
                put(JSONObject().apply {
                    put("encoding", "base64")
                    put("commitment", "processed")
                })
            })
        }
        val resp = postSolanaRpc(reqObj.toString()) ?: return null
        val accVal = resp.optJSONObject("result")?.optJSONObject("value") ?: return null
        return applyPumpCurveAccountBytes(cfg, meta, accVal)
    }

    private fun applyPumpCurveAccountBytes(cfg: LivePoolConfig, meta: TokenInfo, accVal: JSONObject): TokenInfo? {
        val dataArr = accVal.optJSONArray("data") ?: return null
        val b64 = dataArr.optString(0, "")
        if (b64.isEmpty()) return null
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        if (bytes.size < 24) return null

        val vTokenRaw = readU64Le(bytes, 8)
        val vSolRaw = readU64Le(bytes, 16)
        if (vTokenRaw <= 0.0 || vSolRaw <= 0.0) return null

        val currentRatio = vSolRaw / vTokenRaw
        if (cfg.baseRatio <= 0.0) {
            cfg.baseRatio = currentRatio
        }

        // Exact on-chain Pump.fun Market Cap formula: (vSol / 1e9) / (vToken / 1e6) * 1e9 * solUsdPrice
        val priceInSol = (vSolRaw / 1_000_000_000.0) / (vTokenRaw / 1_000_000.0)
        val directMcUsd = priceInSol * 1_000_000_000.0 * meta.solUsdPrice
        val directPriceUsd = priceInSol * meta.solUsdPrice

        val updated = if (directMcUsd in 500.0..50_000_000_000.0) {
            meta.copy(
                marketCap = directMcUsd,
                priceUsd = directPriceUsd
            )
        } else {
            val mult = currentRatio / cfg.baseRatio
            meta.copy(
                marketCap = cfg.baseMc * mult,
                priceUsd = cfg.basePriceUsd * mult
            )
        }
        tokenMetaMap[cfg.ca] = updated
        lastRealtimeUpdateMs[cfg.ca] = System.currentTimeMillis()
        return updated
    }

    /**
     * Reads both the pool's SPL Token Vault and WSOL Vault in a single `getMultipleAccounts` call
     * with "commitment": "processed" (works for PumpSwap, Raydium AMM/CPMM/CLMM, Meteora, Orca).
     */
    private fun pollDualSplVaults(cfg: LivePoolConfig, meta: TokenInfo): TokenInfo? {
        val reqObj = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("id", 1)
            put("method", "getMultipleAccounts")
            put("params", JSONArray().apply {
                put(JSONArray().apply {
                    put(cfg.tokenVault)
                    put(cfg.solVault)
                })
                put(JSONObject().apply {
                    put("encoding", "base64")
                    put("commitment", "processed")
                })
            })
        }
        val resp = postSolanaRpc(reqObj.toString()) ?: return null
        val arr = resp.optJSONObject("result")?.optJSONArray("value") ?: return null
        if (arr.length() < 2) return null

        val tokAcc = arr.optJSONObject(0) ?: return null
        val solAcc = arr.optJSONObject(1) ?: return null

        val tokReserve = decodeSplAccountBalance(tokAcc)
        val solReserve = decodeSplAccountBalance(solAcc).let {
            if (it > 0.0) it else (solAcc.optLong("lamports", 0L).toDouble())
        }

        if (tokReserve <= 0.0 || solReserve <= 0.0) return null
        val currentRatio = solReserve / tokReserve
        if (cfg.baseRatio <= 0.0) {
            cfg.baseRatio = currentRatio
            return meta
        }

        val mult = currentRatio / cfg.baseRatio
        if (mult.isNaN() || mult.isInfinite() || mult <= 0.0001 || mult >= 10000.0) return null

        val updated = meta.copy(
            marketCap = cfg.baseMc * mult,
            priceUsd = cfg.basePriceUsd * mult
        )
        tokenMetaMap[cfg.ca] = updated
        cfg.latestTokenReserve = tokReserve
        cfg.latestSolReserve = solReserve
        lastRealtimeUpdateMs[cfg.ca] = System.currentTimeMillis()
        return updated
    }

    /**
     * Inspects `pairAddress` on-chain once to determine whether it's a Pump.fun Bonding Curve,
     * a Raydium v4 AMM pool, or a PumpSwap/CPMM/Meteora pool owning two SPL token vaults.
     */
    private fun initOnChainPoolForPair(ca: String, pairAddress: String, initialMeta: TokenInfo) {
        try {
            val req = JSONObject().apply {
                put("jsonrpc", "2.0")
                put("id", 1)
                put("method", "getAccountInfo")
                put("params", JSONArray().apply {
                    put(pairAddress)
                    put(JSONObject().apply {
                        put("encoding", "base64")
                        put("commitment", "processed")
                    })
                })
            }
            val resp = postSolanaRpc(req.toString()) ?: return
            val valObj = resp.optJSONObject("result")?.optJSONObject("value") ?: return
            val ownerProgram = valObj.optString("owner", "")
            val dataArr = valObj.optJSONArray("data")
            val b64 = dataArr?.optString(0, "") ?: ""
            val bytes = if (b64.isNotEmpty()) Base64.decode(b64, Base64.DEFAULT) else ByteArray(0)

            // Case 1: Pump.fun Bonding Curve (verify the owning program; size alone is ambiguous).
            if (ownerProgram == PUMPFUN_PROGRAM) {
                val vTok = readU64Le(bytes, 8)
                val vSol = readU64Le(bytes, 16)
                if (vTok > 0.0 && vSol > 0.0) {
                    val cfg = LivePoolConfig(
                        ca = ca,
                        pairAddress = pairAddress,
                        kind = PoolKind.PUMPFUN_CURVE,
                        tokenVault = pairAddress,
                        solVault = pairAddress,
                        baseRatio = vSol / vTok,
                        baseMc = initialMeta.marketCap,
                        basePriceUsd = initialMeta.priceUsd
                    )
                    poolConfigMap[ca] = cfg
                    applyPumpCurveAccountBytes(cfg, initialMeta, valObj)
                    return
                }
            }

            // Case 2: Raydium AMM v4 (752 bytes, baseVault at 336..368, quoteVault at 368..400)
            if (ownerProgram == RAYDIUM_V4_PROGRAM && bytes.size >= 400) {
                val vaultA = encodeBase58(bytes.copyOfRange(336, 368))
                val vaultB = encodeBase58(bytes.copyOfRange(368, 400))
                setupDualVaultConfig(ca, pairAddress, vaultA, vaultB, initialMeta)
                return
            }

            // Case 3: PumpSwap / Raydium CPMM / Meteora / Orca — discover vaults via getTokenAccountsByOwner(pairAddress)
            val vaults = findPoolVaultsByOwner(pairAddress, ca)
            if (vaults != null) {
                setupDualVaultConfig(ca, pairAddress, vaults.first, vaults.second, initialMeta)
            }
        } catch (_: Throwable) {}
    }

    private fun findPoolVaultsByOwner(pairAddress: String, tokenMintCa: String): Pair<String, String>? {
        var tokVault = ""
        var wsolVault = ""

        for (prog in arrayOf(SPL_TOKEN_PROGRAM, TOKEN_2022_PROGRAM)) {
            val req = JSONObject().apply {
                put("jsonrpc", "2.0")
                put("id", 1)
                put("method", "getTokenAccountsByOwner")
                put("params", JSONArray().apply {
                    put(pairAddress)
                    put(JSONObject().apply { put("programId", prog) })
                    put(JSONObject().apply {
                        put("encoding", "jsonParsed")
                        put("commitment", "processed")
                    })
                })
            }
            val res = postSolanaRpc(req.toString()) ?: continue
            val arr = res.optJSONObject("result")?.optJSONArray("value") ?: continue
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val pubkey = item.optString("pubkey", "")
                val info = item.optJSONObject("account")
                    ?.optJSONObject("data")
                    ?.optJSONObject("parsed")
                    ?.optJSONObject("info") ?: continue
                val mint = info.optString("mint", "")
                if (mint == tokenMintCa && pubkey.isNotEmpty()) {
                    tokVault = pubkey
                } else if (mint == WSOL_MINT && pubkey.isNotEmpty()) {
                    wsolVault = pubkey
                }
            }
        }

        if (tokVault.isNotEmpty() && wsolVault.isNotEmpty()) {
            return Pair(tokVault, wsolVault)
        }
        return null
    }

    private fun setupDualVaultConfig(
        ca: String,
        pairAddress: String,
        vault1: String,
        vault2: String,
        initialMeta: TokenInfo
    ) {
        val req = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("id", 1)
            put("method", "getMultipleAccounts")
            put("params", JSONArray().apply {
                put(JSONArray().apply {
                    put(vault1)
                    put(vault2)
                })
                put(JSONObject().apply {
                    put("encoding", "base64")
                    put("commitment", "processed")
                })
            })
        }
        val res = postSolanaRpc(req.toString()) ?: return
        val arr = res.optJSONObject("result")?.optJSONArray("value") ?: return
        if (arr.length() < 2) return
        val acc1 = arr.optJSONObject(0) ?: return
        val acc2 = arr.optJSONObject(1) ?: return

        val mint1 = decodeSplAccountMintBase58(acc1)
        val bal1 = decodeSplAccountBalance(acc1)
        val bal2 = decodeSplAccountBalance(acc2)
        if (bal1 <= 0.0 || bal2 <= 0.0) return

        val isVault1Token = (mint1 == ca)
        val tokVault = if (isVault1Token) vault1 else vault2
        val solVault = if (isVault1Token) vault2 else vault1
        val tokReserve = if (isVault1Token) bal1 else bal2
        val solReserve = if (isVault1Token) bal2 else bal1

        poolConfigMap[ca] = LivePoolConfig(
            ca = ca,
            pairAddress = pairAddress,
            kind = PoolKind.DUAL_SPL_VAULTS,
            tokenVault = tokVault,
            solVault = solVault,
            baseRatio = solReserve / tokReserve,
            baseMc = initialMeta.marketCap,
            basePriceUsd = initialMeta.priceUsd,
            latestTokenReserve = tokReserve,
            latestSolReserve = solReserve
        )
    }

    /**
     * Primary live feed: Solana RPC accountSubscribe notifications at processed commitment.
     * Both AMM vaults are subscribed on the same socket; Pump.fun curves subscribe to the
     * bonding-curve account directly. HTTP RPC is only a throttled recovery fallback.
     */
    private fun ensureWebSocketsRunning(ca: String, onRealtimeUpdate: (TokenInfo) -> Unit) {
        if (subscribedCa == ca && activeSolanaWebSocket != null) return
        subscribedCa = ca

        try { activeSolanaWebSocket?.cancel() } catch (_: Throwable) {}

        val cfg = poolConfigMap[ca] ?: return
        val wsUrl = SOLANA_WS_RPCS[rpcIndex.get().and(1)]
        val request = Request.Builder().url(wsUrl).build()
        val subscriptionToTokenVault = ConcurrentHashMap<Int, Boolean>()
        activeSolanaWebSocket = httpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (cfg.kind == PoolKind.PUMPFUN_CURVE) {
                    val sub = JSONObject().apply {
                        put("jsonrpc", "2.0")
                        put("id", 10)
                        put("method", "accountSubscribe")
                        put("params", JSONArray().apply {
                            put(cfg.pairAddress)
                            put(JSONObject().apply {
                                put("encoding", "base64")
                                put("commitment", "processed")
                            })
                        })
                    }
                    webSocket.send(sub.toString())
                } else {
                    // Subscribe to BOTH reserves on the same socket. Previously only the
                    // SOL vault was subscribed, then every notification caused a slow HTTP read.
                    listOf(
                        11 to cfg.tokenVault,
                        12 to cfg.solVault
                    ).forEach { (id, pubkey) ->
                        val sub = JSONObject().apply {
                            put("jsonrpc", "2.0")
                            put("id", id)
                            put("method", "accountSubscribe")
                            put("params", JSONArray().apply {
                                put(pubkey)
                                put(JSONObject().apply {
                                    put("encoding", "base64")
                                    put("commitment", "processed")
                                })
                            })
                        }
                        webSocket.send(sub.toString())
                    }
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val root = JSONObject(text)
                    // Solana returns a server subscription ID for each request ID.
                    if (root.has("id") && root.has("result")) {
                        val requestId = root.optInt("id", -1)
                        val serverSubId = root.optInt("result", -1)
                        if (serverSubId >= 0) {
                            if (requestId == 11) subscriptionToTokenVault[serverSubId] = true
                            if (requestId == 12) subscriptionToTokenVault[serverSubId] = false
                        }
                        return
                    }
                    if (!text.contains("accountNotification")) return
                    val params = root.optJSONObject("params") ?: return
                    val subscription = params.optInt("subscription", -1)
                    val value = params.optJSONObject("result")?.optJSONObject("value") ?: return
                    val meta = tokenMetaMap[ca] ?: return

                    val updated = if (cfg.kind == PoolKind.PUMPFUN_CURVE) {
                        applyPumpCurveAccountBytes(cfg, meta, value)
                    } else {
                        val reserve = decodeSplAccountBalance(value)
                        if (reserve <= 0.0) return
                        when (subscriptionToTokenVault[subscription]) {
                            true -> cfg.latestTokenReserve = reserve
                            false -> cfg.latestSolReserve = reserve
                            null -> return
                        }
                        val tokenReserve = cfg.latestTokenReserve
                        val solReserve = cfg.latestSolReserve
                        if (tokenReserve <= 0.0 || solReserve <= 0.0) return
                        val ratio = solReserve / tokenReserve
                        val mult = ratio / cfg.baseRatio
                        if (!mult.isFinite() || mult <= 0.0001 || mult >= 10000.0) return
                        meta.copy(
                            marketCap = cfg.baseMc * mult,
                            priceUsd = cfg.basePriceUsd * mult
                        ).also { tokenMetaMap[ca] = it }
                    }

                    if (updated != null) {
                        lastRealtimeUpdateMs[ca] = System.currentTimeMillis()
                        onRealtimeUpdate(updated)
                    }
                } catch (_: Throwable) {}
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (activeSolanaWebSocket === webSocket) activeSolanaWebSocket = null
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (activeSolanaWebSocket === webSocket) activeSolanaWebSocket = null
            }
        })
    }

    private fun decodeSplAccountBalance(accountObj: JSONObject): Double {
        return try {
            val dataArr = accountObj.optJSONArray("data") ?: return 0.0
            val b64 = dataArr.optString(0, "")
            if (b64.isEmpty()) return 0.0
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            if (bytes.size < 72) return 0.0
            readU64Le(bytes, 64)
        } catch (_: Throwable) {
            0.0
        }
    }

    private fun decodeSplAccountMintBase58(accountObj: JSONObject): String {
        return try {
            val dataArr = accountObj.optJSONArray("data") ?: return ""
            val b64 = dataArr.optString(0, "")
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            if (bytes.size < 32) return ""
            encodeBase58(bytes.copyOfRange(0, 32))
        } catch (_: Throwable) {
            ""
        }
    }

    private fun readU64Le(bytes: ByteArray, offset: Int): Double {
        if (bytes.size < offset + 8) return 0.0
        val buf = ByteBuffer.wrap(bytes, offset, 8).order(ByteOrder.LITTLE_ENDIAN)
        val raw = buf.long
        return if (raw >= 0L) raw.toDouble() else ((raw ushr 1).toDouble() * 2.0)
    }

    private fun encodeBase58(input: ByteArray): String {
        val alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
        var zeros = 0
        while (zeros < input.size && input[zeros].toInt() == 0) zeros++
        val copy = input.copyOf()
        val encoded = CharArray(copy.size * 2)
        var outputStart = encoded.size
        var startAt = zeros
        while (startAt < copy.size) {
            var remainder = 0
            for (i in startAt until copy.size) {
                val digit256 = copy[i].toInt() and 0xFF
                val temp = remainder * 256 + digit256
                copy[i] = (temp / 58).toByte()
                remainder = temp % 58
            }
            if (copy[startAt].toInt() == 0) startAt++
            encoded[--outputStart] = alphabet[remainder]
        }
        while (outputStart < encoded.size && encoded[outputStart] == alphabet[0]) outputStart++
        repeat(zeros) { encoded[--outputStart] = alphabet[0] }
        return String(encoded, outputStart, encoded.size - outputStart)
    }

    private fun postSolanaRpc(jsonBody: String): JSONObject? {
        val url = SOLANA_HTTP_RPCS[rpcIndex.incrementAndGet().and(1)]
        return try {
            val req = Request.Builder()
                .url(url)
                .post(jsonBody.toRequestBody(JSON_MEDIA))
                .header("Cache-Control", "no-cache")
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val bodyStr = resp.body?.string() ?: return null
                JSONObject(bodyStr)
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun fetchBestSolanaPairJson(url: String, isArray: Boolean): JSONObject? {
        return try {
            val req = Request.Builder()
                .url(url)
                .header("Cache-Control", "no-cache")
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val raw = resp.body?.string() ?: return null
                val arr = if (isArray) JSONArray(raw) else JSONObject(raw).optJSONArray("pairs")
                if (arr == null || arr.length() == 0) return null

                var best: JSONObject? = null
                var maxLiq = -1.0
                for (i in 0 until arr.length()) {
                    val p = arr.optJSONObject(i) ?: continue
                    val chain = p.optString("chainId")
                    if (chain.isNotEmpty() && chain != "solana") continue
                    val liq = p.optJSONObject("liquidity")?.optDouble("usd", 0.0) ?: 0.0
                    if (liq > maxLiq || best == null) {
                        maxLiq = liq
                        best = p
                    }
                }
                best ?: arr.optJSONObject(0)
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun parsePairToTokenInfo(pair: JSONObject, originalCa: String): TokenInfo? {
        val baseToken = pair.optJSONObject("baseToken") ?: return null
        val name = baseToken.optString("name", "Solana Token")
        val symbol = baseToken.optString("symbol", "TOKEN")
        val address = baseToken.optString("address", originalCa)

        val priceUsd = pair.optString("priceUsd", "0.0").toDoubleOrNull() ?: 0.00001
        val priceNative = pair.optString("priceNative", "0.0").toDoubleOrNull() ?: 0.0
        val solUsd = if (priceNative > 0.0 && priceUsd > 0.0) {
            val implied = priceUsd / priceNative
            if (implied in 10.0..2000.0) implied else TradeRepository.settings.solUsdPrice
        } else {
            TradeRepository.settings.solUsdPrice
        }

        val mc = when {
            pair.has("marketCap") && !pair.isNull("marketCap") -> pair.optDouble("marketCap", priceUsd * 1_000_000_000.0)
            pair.has("fdv") && !pair.isNull("fdv") -> pair.optDouble("fdv", priceUsd * 1_000_000_000.0)
            else -> priceUsd * 1_000_000_000.0
        }

        val vol24 = pair.optJSONObject("volume")?.optDouble("h24", 0.0) ?: 0.0
        val liqUsd = pair.optJSONObject("liquidity")?.optDouble("usd", 0.0) ?: 0.0
        val imageUrl = pair.optJSONObject("info")?.optString("imageUrl", "") ?: ""

        return TokenInfo(
            ca = address,
            name = name,
            symbol = symbol,
            priceUsd = priceUsd,
            solUsdPrice = solUsd,
            marketCap = mc,
            liquidityUsd = liqUsd,
            volume24h = vol24,
            imageUrl = imageUrl
        )
    }

    fun loadTokenBitmap(url: String, onLoaded: (Bitmap?) -> Unit) {
        if (url.isEmpty()) {
            onLoaded(null)
            return
        }
        val cached = bitmapCache.get(url)
        if (cached != null) {
            onLoaded(cached)
            return
        }
        imageExecutor.execute {
            try {
                val req = Request.Builder().url(url).build()
                httpClient.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val bytes = resp.body?.bytes()
                        if (bytes != null) {
                            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                            if (bmp != null) bitmapCache.put(url, bmp)
                            onLoaded(bmp)
                            return@execute
                        }
                    }
                }
            } catch (_: Throwable) {}
            onLoaded(null)
        }
    }
}
